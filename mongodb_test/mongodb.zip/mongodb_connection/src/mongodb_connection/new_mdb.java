package mongodb_connection;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class new_mdb {

	
	public static void main(String[] args) {
		/*
		
		MongoClient client = new MongoClient("localhost", 27017);
		MongoDatabase database = client.getDatabase("bigdata_project_database");
		MongoCollection<Document> collection = database
				.getCollection("podcast_details");
		//update
		/*
		Bson filter = new Document("name", "akshay");
		Bson newValue = new Document("age", 24);
		Bson updateOperationDocument = new Document("$set", newValue);
		collection.updateOne(filter, updateOperationDocument);
		//update
	//	FindIterable<Document> cursor2 = collection.find();
	/*	while(cursor2.iterator().hasNext())
		{
			System.out.println(cursor2.iterator().next());
		}
			*/
		//put
		
		MongoClient mongo = new MongoClient("localhost", 27017);
		DB db = mongo.getDB("bigdata_project_database");//database
		
		DBCollection table = db.getCollection("podcast_details");
		/*
		BasicDBObject document = new BasicDBObject();
		
		document.put("title", "Rahdo Talks Through");
		
		List<BasicDBObject> authors = new ArrayList<>();
		BasicDBObject author = new BasicDBObject();
		author.put("author1","podcast@rahdo.com");
		authors.add(author);
		document.put("authors", authors);
		
		document.put("itunesId", "1000016089");
		document.put("feedUrl", "http://feeds.feedburner.com/RahdoTalksThrough");
		document.put("description", "A monthly podcast all about boardgames, hosted by Richard \"Rahdo\" Ham");
		document.put("category", "Games & Hobbies");
		
		List<BasicDBObject> episodes = new ArrayList<>();		
		String[] title = {"RTT Episode #1","RTT Episode #2"};
		String[] description = {"Dominion, a thematic game! How to start a boardgame cafe! Filler Games galore! SHOW NOTES: •••What Have We've Been Playing? (00:01:54)►►► Dead Men Tell No Tales, New York 1901, Stockpile, Kraftwagen, Parfum, Queen's Architect •••Games of Interest (00:23:05)►►► 7th Continent, Oracle of Delphi, Solar 3X, Manhattan Project Chain Reaction, Carson City Horses & Heroes, Signorie, Samara, Centerville •••Q&A (00:36:10)►►► Send your fragen to questions@rahdo.com! •••Victory Point Cafe Interview (00:36:54)►►► Check out the kickstarter at https://www.kickstarter.com/projects/vpcafe/victory-point-cafe-berkeleys-first-board-game-cafe •••Thematic Review (00:57:37)►►► Dominion... that's right! Dominion! •••Top 10 Revisited (01:07:11)►►► Filler games! Original top10 video: https://www.youtube.com/watch?v=6mo9cg3IwbI •••Direct MP3 link: https://ia601501.us.archive.org/24/items/RTT001/RTT-001.mp3 •••Subscribe: http://feeds.feedburner.com/RahdoTalksThrough","Too many new games! Questions (plus) Answers! Engine building games broken down! SHOW NOTES: •••What Have We've Been Playing? (00:01:40)►►► Elysium, Voyages of Marco Polo, Specter Ops, Cthulhu Realms, Flip City, Dungeon of Fortune, Bottlecap Vikings •••Games of Interest (01:09:55)►►► Legends of Andor: Chada & Thorn, The Loser's Club, Unnamed Castles of Burgundy Sequel, Council of Four, Rattle Battle Grab the Loot, Dice City, Shadowrift 2nd Edition, Legacy Time Surge, Shadowrun Crossfire High Caliber Ops, Villages of Valeria, Minerva, Shakespeare, Apollo XIII, Octo Dice •••Q&A (01:40:02)►►► How often do we play games? Do we ever play \"mean\" games? Do we miss playing with more than 2? Am I going to design my own game? Would I take a prototype to a publisher or Kickstarter? How does the boardgame industry compare to the videogame industry?  How did you relocate from the US to Malta?  More questions? Send your fragen to questions@rahdo.com! •••Top 10 Revisited (02:16:35)►►► Engine building games! Original top10 video: https://www.youtube.com/watch?v=KAKtwJa9J4s •••Direct MP3 link: https://ia601502.us.archive.org/6/items/RTT002/RTT-002.mp3 •••Subscribe: http://feeds.feedburner.com/RahdoTalksThrough"};
		for (int i=0;i<title.length;i++){
		BasicDBObject each_episodes = new BasicDBObject();
		each_episodes.put("title", title[i]);
		each_episodes.put("description", description[i]);
		episodes.add(each_episodes);
		}
		
		document.put("episodes", episodes);
		
		table.insert(document);
	*/
	//2nd podcast
		/*
		BasicDBObject document1 = new BasicDBObject();
		
		document1.put("title", "second podcast2");
		
		List<BasicDBObject> authors1 = new ArrayList<>();
		BasicDBObject author1 = new BasicDBObject();
		author1.put("author1","akshay@rahdo.com");
		authors1.add(author1);
		document1.put("authors", authors1);
		
		document1.put("itunesId", "1245978");
		document1.put("feedUrl", "http://feeds.feedburner.com/RahdoTalksThrough");
		document1.put("description", "A weekly podcast all about video games, hosted by Akshay \"Rahdo\" Ham");
		document1.put("category", "Video games");
		
		List<BasicDBObject> episodes1 = new ArrayList<>();		
		String[] title1 = {"Games 1 Episode #1","Games 2 Episode #2"};
		String[] description1 = {"first episode intro to games","second episode review new games"}; 
		for (int i=0;i<title1.length;i++){
		BasicDBObject each_episodes1 = new BasicDBObject();
		each_episodes1.put("title", title1[i]);
		each_episodes1.put("description", description1[i]);
		episodes1.add(each_episodes1);
		}
		
		document1.put("episodes", episodes1);
		
		table.insert(document1);
	
		
		
		//2ndpodcast
		
		*/
		
		//put
		
		
		//find
		
		BasicDBObject searchQuery = new BasicDBObject();
		BasicDBObject allQuery = new BasicDBObject();
	//	searchQuery.put("name", "mkyong");
		searchQuery.put("title", "second podcast2");

	//	DBCursor cursor = table.find(searchQuery);
		DBCursor cursor = table.find(searchQuery);

		ArrayList<Podcast> podcasts = new ArrayList<Podcast>();
		
		while (cursor.hasNext()) {
		//	System.out.println(cursor.next());
			DBObject o = cursor.next();
		//	String title =  o.get("title").toString();
//			System.out.println(title);
			
			String podcast_title =  o.get("title").toString();
			List<DBObject> authors = (List<DBObject>) o.get("authors");
			String[] authors_list = new String[authors.size()];
			int i= 0;
			for (DBObject author: authors ){
			authors_list[i] =  author.get("author"+(i+1)).toString();
			}
			
			String itunesId =  o.get("itunesId").toString();
			String feedUrl =  o.get("feedUrl").toString();
			String description =  o.get("description").toString();
			String category =  o.get("category").toString();
	//		String episodes =  o.get("episodes").toString();
			
			List<DBObject> episodes = (List<DBObject>) o.get("episodes");
			ArrayList<String[]> episodes_list = new ArrayList<String[]>();
			String[] each_episode = new String[2];
			
			for (DBObject episode: episodes ){
				int j= 0;
				each_episode[j] = episode.get("title").toString();
				j++;
				each_episode[j] = episode.get("description").toString();
				episodes_list.add(each_episode);
			}
			Podcast podcast_details = new Podcast(podcast_title,authors_list
					,itunesId,feedUrl,description,category,episodes_list);
			
			podcasts.add(podcast_details);
		}
		
		for(Podcast p : podcasts) {
		    System.out.println(p.title.toString());  
		}
		
		
		
		//find
		
		
		
	}
	
	
}
