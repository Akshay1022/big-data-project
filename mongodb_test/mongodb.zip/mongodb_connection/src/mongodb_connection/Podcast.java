package mongodb_connection;

import java.util.ArrayList;

public class Podcast {
	String title;
	String authors[];
	String itunesId;
	String feedurl;
	String description;
	String category;
	ArrayList<String[]> episodes  = new ArrayList<String[]>();

	public Podcast(String title,String authors[],String itunesid,String feedurl
			,String description, String category, ArrayList<String[]> episodes)
	{
		this.title = title;
		this.authors = authors;
		this.itunesId = itunesid;
		this.feedurl = feedurl;
		this.description = description;
		this.category = category;
		this.episodes = episodes;
	}
	
	
}
